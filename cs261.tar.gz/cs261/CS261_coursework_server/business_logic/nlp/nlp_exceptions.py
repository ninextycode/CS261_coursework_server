class MeaningUnknown(Exception):
    pass