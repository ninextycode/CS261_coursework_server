import os
import inspect
import config


pages_folder = config.static_folder

news_page_path = os.path.join(config.static_folder, 'news.html')