DROP TABLE Historical_Prices;
DROP TABLE Companies;
DROP TABLE Sectors;