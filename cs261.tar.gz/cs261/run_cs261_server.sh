cd ./CS261_coursework_server && sudo docker-compose up --build server
