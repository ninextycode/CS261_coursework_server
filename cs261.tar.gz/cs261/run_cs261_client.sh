cd CS261_coursework_server && sudo docker-compose up -d --build mysql
sudo docker-compose up -d --build mongodb
cd ../CS261_coursework_client && sh setup_docker_net.sh && sudo docker-compose up -d --build client
