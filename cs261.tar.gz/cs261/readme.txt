tested on kubuntu 16.04

first run script "run_cs261_client.sh"
then run script "run_cs261_server.sh"
After that, wait several minutes for database to set up and fill initial values.
Open fronted html file, path to this file is CS261_coursework_client/frontend/frontend.html